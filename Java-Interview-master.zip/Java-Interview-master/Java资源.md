---
title: 一份薄礼 
date: 2019-02-04 09:37:35
img: https://images.pexels.com/photos/360912/pexels-photo-360912.jpeg?auto=compress&cs=tinysrgb&dpr=1
top: true
summary: 在这里，没有所谓的价值上千元的几百个G的某架构培训视频，只有我看过的，不禁让人拍手称快的，个人感觉是真正用新做教育和技术分享的视频教程，他们不会闲你教的学费太少而有所保留。左神、汪文君老师等，感谢你们开启了我的知识大门……在这里我也将这些视频分享给各位，只有大家相互分享，大家才能更好的协同进步渡过难关，fighting！
categories: 视频教程
tags: 视频教程
create_by:https://github.com/zanwen/my-offer-to-java
---



## 数据结构和算法

### 1、直通BAT算法

初级班+进阶班：链接: https://pan.baidu.com/s/1PcwJUt2yLPfrOEvAA2wv7Q 提取码: i4q2

笔者对视频中的知识点做了总结：

- 基础篇：http://www.zhenganwen.top/posts/62859a9a/
- 进阶篇：http://www.zhenganwen.top/posts/19e411e9/

## 数据库

### 1、MySQL优化

链接: https://pan.baidu.com/s/1lc9qK6QwiCIjGEbqFrp6XQ 提取码: y89t

笔者总结：http://www.zhenganwen.top/posts/62645e84/

## 网络协议

### 1.、计算机网络精讲视频

链接: https://pan.baidu.com/s/1KqciniE9OJD9-vFlAaXuxg 提取码: bud4

## 并发编程

### 1、老汪并发和多线程三阶段

> 老汪出品必属精品，谁看谁知道，淘宝店“心蓝说Java”，可跟客服砍价

第一阶段、并发和多线程基础：链接: https://pan.baidu.com/s/1Cnwvlf9jvPAnJsFhqhDF2g 提取码: 9v91


第二阶段、并发和多线程设计模式：链接: https://pan.baidu.com/s/1GpzAy8KNON3T2s_oxC85qQ 提取码: u6d5

第三阶段、JUC详解：链接: https://pan.baidu.com/s/1CI8qX-hkaMQuSosnUIP3og 提取码: 7020





